[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH /var/www/html/vendor/illuminate/mail/resources/views/text/header.blade.php ENDPATH**/ ?>