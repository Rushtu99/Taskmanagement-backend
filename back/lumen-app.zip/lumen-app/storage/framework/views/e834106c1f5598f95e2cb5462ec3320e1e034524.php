<?php echo e($slot); ?>

<?php /**PATH /var/www/html/vendor/illuminate/mail/resources/views/text/footer.blade.php ENDPATH**/ ?>